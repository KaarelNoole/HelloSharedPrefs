package com.example.hellosharedprefs;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

// Projekt töötab aga soovin veel asju hiljem muuta.

//  When entering the Settings activity, current background style and color are sent as an intent extra.
//  The options in the Settings activity are pre-selected depending on what data was sent from MainActivity through intent extras.
//  After clicking Apply or Reset in the Settings activity, the Shared Preferences file is changed and when MainActivity goes through
//  the onCreate() cycle, it will read the new data through Shared Preferences, not through a reply intent.

public class MainActivity extends AppCompatActivity {

    // An integer variable used for labelling which background shape is being used for the count TextView
    private int backgroundType;

    // An integer variable used for storing the current count
    private int mCount = 0;

    // An integer variable used for storing the ContextCompat value of the background color
    private int mColor;

    // TextView variable tied to the count TextView in the .xml layout
    private TextView txtCount;

    // Intent extra keys for sending values into the settings activity
    public static final String BACKGROUND_KEY = "background";
    public static final String COLOR_KEY = "color";
    public static final String COUNT_KEY = "count";

    // Initiate a SharedPreferences variable
    SharedPreferences mPreferences;

    // Create a file for storing the shared preferences of this app
    public static final String sharedPrefFile = "com.example.hellosharedprefs";



    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Tie the TextView from the .xml layout to the code
        txtCount = findViewById(R.id.count_textview);

        // Give the SharedPreferences variable a value, sharedPrefFile is the file name and MODE_PRIVATE is the mode
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);

        // Restore the data from SharedPreferences
        mCount = mPreferences.getInt(COUNT_KEY, 0);
        txtCount.setText(String.format("%s", mCount));
        mColor = mPreferences.getInt(COLOR_KEY, ContextCompat.getColor(this, R.color.default_background));
        txtCount.setBackgroundTintList(ColorStateList.valueOf(mColor));
        backgroundType = mPreferences.getInt(BACKGROUND_KEY, 0);
        setBackgroundType(backgroundType);
    }

    // This method changes the count TextView's background based on what the value of the backgroundType integer is
    @SuppressLint("UseCompatLoadingForDrawables")
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void setBackgroundType(int backgroundType) {
        switch (backgroundType){
            case 1:
                txtCount.setBackground(getDrawable(R.drawable.rounded_corner));
                break;
            default: txtCount.setBackground(getDrawable(R.color.default_background));
        }
    }

    // Simple method which increases the count variable and updates the count TextView in the layout
    public void onCount(View view) {
        mCount++;
        txtCount.setText(String.format("%s", mCount));
    }

    // Start the settings activity and send the current background shape variable and color integer values as an intent extra
    public void onSettings(View view) {
        Intent intent = new Intent(this, SettingsActivity.class);
        intent.putExtra(BACKGROUND_KEY, backgroundType);
        intent.putExtra(COLOR_KEY, mColor);
        startActivity(intent);
    }

    // Whenever the MainActivity is paused, it stores the value of the count variable and it is reloaded in the onCreate() cycle
    @Override
    protected void onPause() {
        super.onPause();
        // SharedPreferences editor is used to write the shared preferences object for what we store.
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();

        // Storing the count value with putInt()
        // The keys for these integer are previously declared string variables
        preferencesEditor.putInt(COUNT_KEY, mCount);

        // apply() is used to finish and save the editor activity (async)
        preferencesEditor.apply();
    }
}