package com.example.hellosharedprefs;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

public class SettingsActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    // Spinner for selecting the count TextView's background color
    private Spinner colorSpinner;
    private ArrayAdapter<CharSequence> adapter;

    // Variables for storing the values of the TextView count, background color and shape
    private int mCount, mColor, backgroundType;

    Intent intent;

    SharedPreferences mPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Give the SharedPreferences variable a value, sharedPrefFile is the file name and MODE_PRIVATE is the mode
        mPreferences = getSharedPreferences(MainActivity.sharedPrefFile, MODE_PRIVATE);

        // Reading the colors string array resource and creating an adapter for the spinner
        adapter = ArrayAdapter.createFromResource(this, R.array.colors, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Tying the .xml spinner with the code, tying it with the created adapter and setting up the item selected listener
        colorSpinner = findViewById(R.id.colorSpinner);
        colorSpinner.setAdapter(adapter);
        colorSpinner.setOnItemSelectedListener(this);

        // Getting the MainActivity intent and setting our variable values to the received intent extras
        intent = getIntent();
        mColor = intent.getIntExtra(MainActivity.COLOR_KEY, 0);
        backgroundType = intent.getIntExtra(MainActivity.BACKGROUND_KEY, 0);

        // Check what background color was being used in MainActivity, and pre-select the appropriate spinner option
        if (mColor == ContextCompat.getColor(this, R.color.black)) colorSpinner.setSelection(1);
        else if (mColor == ContextCompat.getColor(this, R.color.red_background))
            colorSpinner.setSelection(2);
        else if (mColor == ContextCompat.getColor(this, R.color.blue_background))
            colorSpinner.setSelection(3);
        else if (mColor == ContextCompat.getColor(this, R.color.green_background))
            colorSpinner.setSelection(4);
        else colorSpinner.setSelection(0);
    }


    // Apply button on click listener
    public void onApply(View view) {
        // SharedPreferences editor is used to write the shared preferences object for what we store.
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();

        // Storing the count and color integer values with putInt()
        // The keys for these integer are previously declared string variables
        preferencesEditor.putInt(MainActivity.COLOR_KEY, mColor);
        preferencesEditor.putInt(MainActivity.BACKGROUND_KEY, backgroundType);

        // apply() is used to finish and save the editor activity (async)
        preferencesEditor.apply();

        // Finish the activity
        finish();

        // Using startActivity() here so the MainActivity goes through the onCreate() cycle again
        intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    // Reset button on click listener
    public void onReset(View view) {

        // SharedPreferences editor is used to write the shared preferences object for what we store.
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();

        // Clear all the shared preferences values
        // MainActivity code in onCreate() will set the assigned default values
        preferencesEditor.clear();

        // apply() is used to finish and save the editor activity (async)
        preferencesEditor.apply();

        // Finish this activity
        finish();

        // Using startActivity() here solely so the MainActivity goes through the onCreate() cycle again
        intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    // Listener for when an item is clicked on in the spinner
    // For each case, the background color integer variable is set to a ContextCompat color
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        switch (i) {
            case 0:
                mColor = ContextCompat.getColor(this, R.color.default_background);
                break;
            case 1:
                mColor = ContextCompat.getColor(this, R.color.black);
                break;
            case 2:
                mColor = ContextCompat.getColor(this, R.color.red_background);
                break;
            case 3:
                mColor = ContextCompat.getColor(this, R.color.blue_background);
                break;
            case 4:
                mColor = ContextCompat.getColor(this, R.color.green_background);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}